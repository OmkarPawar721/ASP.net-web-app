﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectManagementApp.Migrations
{
    /// <inheritdoc />
    public partial class Things : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Projects",
                keyColumn: "ProjectId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 12, 15, 21, 45, 51, 582, DateTimeKind.Local).AddTicks(9724));

            migrationBuilder.UpdateData(
                table: "Projects",
                keyColumn: "ProjectId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 12, 15, 21, 45, 51, 582, DateTimeKind.Local).AddTicks(9760));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Projects",
                keyColumn: "ProjectId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 12, 15, 21, 40, 2, 840, DateTimeKind.Local).AddTicks(4460));

            migrationBuilder.UpdateData(
                table: "Projects",
                keyColumn: "ProjectId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 12, 15, 21, 40, 2, 840, DateTimeKind.Local).AddTicks(4491));
        }
    }
}
