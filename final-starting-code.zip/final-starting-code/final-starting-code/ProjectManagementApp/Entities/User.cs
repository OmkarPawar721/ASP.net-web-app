﻿using Microsoft.AspNetCore.Identity;

namespace ProjectManagementApp.Entities
{
    public class User : IdentityUser
    {
        // TODO: add app-specific props
    }
}
