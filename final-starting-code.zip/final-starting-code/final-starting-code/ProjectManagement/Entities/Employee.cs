﻿using System.ComponentModel.DataAnnotations;

namespace ProjectManagement.Entities
{
    public class Employee
    {
        public int EmployeeId { get; set; }


        [Required(ErrorMessage = "Please enter employee number")]
        	//[RegularExpression(@"^[A - Z]{3}-[0-9]{6}", ErrorMessage = "Please enter employee number in correct format")]
        public string? EmployeeNumber { get; set; }

        [Required(ErrorMessage = "Please enter First Name.")]
        public string? FirstName { get; set; }
        [Required(ErrorMessage = "Please enter last name.")]
        public string? LastName { get; set; }

        public string? FullName
        {
            get
            {
                return $"{LastName}, {FirstName}";
            }
        }

        // FK:
        public int? ProjectId { get; set; }

        // And nav prop:
        public Project? Project { get; set; }
    }
}
